<?php
$title = $_GET['name'];
include "rosbrowse.inc";
$xquery = "/pkgs/package/@repo_host";
$repos = array_unique($xml->xpath($xquery));
?>
<table>
<tr><th>Name</th><th>Packages</th></tr>
<?php
function alpha_cb($a, $b)
{
  return strcmp(strtoupper($a), strtoupper($b));
}
usort($repos, "alpha_cb");
foreach($repos as $repo)
{
  $repo_pkgs = $xml->xpath("/pkgs/package[@repo_host='".$repo."']");
  echo "<tr><td class='pkgname'>";
  echo "<a href=\"repo.php?repo_host=" . urlencode($repo) . "\">" . $repo. "</a>";
  echo "</td><td>";
  echo count($repo_pkgs);
  echo "</td></tr>\n";
}
?>
</table>
</body>
</html>
