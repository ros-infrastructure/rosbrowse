<?php
$title = $_GET['name'];
include "rosbrowse.inc";
$xquery = "/pkgs/package[@name='{$_GET['name']}']";
$pkg = $xml->xpath($xquery);
$pkg = $pkg[0];
?>
<h1><?php echo $pkg['name']; ?></h1>
<p><i><?php echo (string)$pkg->description['brief']; ?></i></p>
<p><b>Author(s):</b> <?php echo $pkg->author; ?></p>
<p><b>License:</b> <?php echo $pkg->license; ?></p>
<p><b>Repository:</b> <?php echo $pkg['repo_host'] ?> &nbsp;&nbsp; <a href="<?php echo $pkg['repo'] . $pkg['path']; ?>"> browse code </a></p>
<?php if ($pkg->url) { ?>
<p><b>Website:</b> <a href="<?php echo $pkg->url ?>"><?php echo $pkg->url; ?></a></p>
<?php } ?>
<?php if ($pkg->depend) { ?>
<p><b>Dependencies:</b>
<?php
foreach($pkg->depend as $dep)
{
  echo "<a href=\"details.php?name=" . urlencode($dep['package']) . "\">" . $dep['package'] . "</a>&nbsp;&nbsp;&nbsp; ";
}
?>
</p>
<?php } ?>
<p><b>Description:</b> <?php echo $pkg->description; ?></p>
<hr />
<p><a href="list.php">Return to list of all packages</a></p>
</table>
</body>
</html>

