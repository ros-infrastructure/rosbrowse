<?php
$title = "search results";
include "rosbrowse.inc";
$pkgs = $xml->xpath("/pkgs/package");
$results = array();
?>

<?php
function alpha_cb($a, $b)
{
  return strcmp(strtoupper($a['name']), strtoupper($b['name']));
}
usort($pkgs, "alpha_cb");
$query = strtoupper($_GET['q']);
foreach($pkgs as $pkg)
{
  $brief_desc = strtoupper((string)$pkg->description['brief']);
  $desc = strtoupper((string)$pkg->description);
  $author = strtoupper((string)$pkg->author);
  $name = strtoupper((string)$pkg['name']);
  if (strpos($brief_desc, $query) !== false ||
      strpos($desc, $query) !== false ||
      strpos($author, $query) !== false ||
      strpos($name, $query) !== false)
    $results[] = $pkg;
}
?>
  <h2>Found <?php echo count($results); ?> packages relating to '<?php echo $_GET['q']; ?>'</h2>
<?php if (count($results) > 0) { ?>
<table>
<tr><th>Name</th><th>Description</th></tr>
<?php
foreach($results as $pkg)
{
  $name = (string)$pkg['name'];
  $desc = (string)$pkg->description['brief'];
  if (strlen($desc) < 10)
  {
    $desc = (string)$pkg->description; //).substr(0, 100);
    $desc = substr($desc, 0, 100);
    if (strlen($desc) == 100)
      $desc .= "...";
  }

  echo "<tr><td class='pkgname'>";
  echo "<a href=\"details.php?name=" . urlencode($name) . "\">" . $name . "</a>";
  echo "</td><td>" . $desc . "</td></tr>\n";
}
?>
</table>
<?php } ?>
</body>
</html>

